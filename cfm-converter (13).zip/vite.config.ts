
import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';

// https://vitejs.dev/config/
export default defineConfig(({ mode }) => {
  // Laad env bestanden op basis van de huidige mode (development/production)
  // Fix: Cast process to any to access cwd() when node types are not fully recognized in the config environment
  const env = loadEnv(mode, (process as any).cwd(), '');
  
  return {
    plugins: [react()],
    define: {
      // Dit zorgt ervoor dat de API_KEY van Netlify (of lokaal) 
      // hardcoded in de build terechtkomt waar 'process.env.API_KEY' staat.
      'process.env.API_KEY': JSON.stringify(env.API_KEY || process.env.API_KEY),
    },
    build: {
      outDir: 'dist',
      sourcemap: false, // Uitzetten voor productie op Netlify voor betere performance
      minify: 'esbuild',
    }
  };
});
