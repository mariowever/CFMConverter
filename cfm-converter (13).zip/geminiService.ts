import { GoogleGenAI, Type } from "@google/genai";
import { ExtractionResult } from "./types";

export const extractDocumentData = async (
  fileBase64: string, 
  mimeType: string
): Promise<ExtractionResult> => {
  // Always use the direct process.env.API_KEY string when initializing the GoogleGenAI client instance
  // Assume process.env.API_KEY is pre-configured as per guidelines
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  // Gebruik gemini-3-pro-preview voor complexe OCR taken op officiële documenten
  const model = 'gemini-3-pro-preview';
  
  const prompt = `
    Je bent een expert in OCR en data-extractie voor Arubaanse overheidsdocumenten.
    Haal de volgende informatie zo nauwkeurig mogelijk op:

    1. CRV nr: Zoek naar "CRV" of "ID" nummer.
    2. ALG: Zoek naar het "ALG" nummer.
    3. Naam: Volledige naam (GEEN komma's gebruiken!).
    4. Adres: Het volledige adres.

    Reageer uitsluitend in JSON.
  `;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: {
        parts: [
          { text: prompt },
          {
            inlineData: {
              data: fileBase64.includes(',') ? fileBase64.split(',')[1] : fileBase64,
              mimeType: mimeType
            }
          }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            crv: { type: Type.STRING },
            alg: { type: Type.STRING },
            naam: { type: Type.STRING },
            adres: { type: Type.STRING }
          },
          required: ["crv", "alg", "naam", "adres"]
        }
      }
    });

    // The response.text property directly returns the extracted string output
    const text = response.text;
    if (!text) throw new Error("AI kon geen tekst vinden.");
    
    return JSON.parse(text) as ExtractionResult;
  } catch (error: any) {
    console.error("Gemini Error:", error);
    // Generic error handling to avoid revealing internal infrastructure details
    throw new Error(`Scan fout: ${error.message || "Onbekende fout"}`);
  }
};