
import React from 'react';

interface LogoProps {
  className?: string;
}

export const Logo: React.FC<LogoProps> = ({ className = "h-12 w-auto" }) => {
  return (
    <svg 
      viewBox="0 0 400 350" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg" 
      className={className}
    >
      {/* House Top Left (Cyan) */}
      <path d="M200 50L80 140V240L200 210V50Z" fill="#40C4D4" />
      
      {/* House Top Right (Dark Blue) */}
      <path d="M200 50L320 140V240L200 210V50Z" fill="#1E59A8" />
      
      {/* White inner cut (Optional, to match the "hollow" look) */}
      <path d="M200 90L130 145V205L200 185L270 205V145L200 90Z" fill="white" fillOpacity="0.1" />

      {/* Blue Wave */}
      <path 
        d="M60 210C60 210 130 140 200 210C270 280 340 210 340 210V250C340 250 270 320 200 250C130 180 60 250 60 250V210Z" 
        fill="#1E59A8" 
      />
      
      {/* Lime Green Wave */}
      <path 
        d="M60 240C60 240 130 170 200 240C270 310 340 240 340 240V280C340 280 270 350 200 280C130 210 60 280 60 280V240Z" 
        fill="#9BC83B" 
      />
      
      {/* Forest Green Wave */}
      <path 
        d="M60 270C60 270 130 200 200 270C270 340 340 270 340 270V320C340 320 270 390 200 320C130 250 60 320 60 320V270Z" 
        fill="#2D9344" 
      />
    </svg>
  );
};
