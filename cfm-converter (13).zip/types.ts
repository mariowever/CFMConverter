
export interface ExtractedDocument {
  id: string;
  userId: string; // Gekoppeld aan de gebruiker
  fileName: string;
  crv: string;
  alg: string;
  naam: string;
  adres: string;
  status: 'pending' | 'processing' | 'completed' | 'error';
  error?: string;
  createdAt: string;
}

export interface ExtractionResult {
  crv: string;
  alg: string;
  naam: string;
  adres: string;
}

export type UserRole = 'admin' | 'user';

export interface User {
  id: string;
  username: string;
  password: string;
  role: UserRole;
  isActive: boolean;
  createdAt: string;
}
