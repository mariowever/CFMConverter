// Fix: Use named import for Dexie to ensure base class methods like 'version' are correctly inherited and recognized by the TypeScript compiler
import { Dexie, type Table } from 'dexie';
import { User, ExtractedDocument } from './types';

// Extend Dexie to ensure the class and its methods like .version() are correctly recognized
export class CFMDatabase extends Dexie {
  users!: Table<User>;
  documents!: Table<ExtractedDocument>;

  constructor() {
    super('CFM_Converter_DB');
    // Use the version method inherited from the Dexie base class to define the database schema
    this.version(1).stores({
      // Primary keys for UUID-based models should not use the '++' auto-increment prefix
      users: 'id, username, role',
      documents: 'id, userId, status, createdAt'
    });
  }
}

export const db = new CFMDatabase();