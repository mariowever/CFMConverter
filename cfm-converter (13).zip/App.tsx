
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { ExtractedDocument, User } from './types';
import { extractDocumentData } from './geminiService';
import { Logo } from './Logo';
import { db } from './db';
import { 
  Trash2, 
  Download, 
  Loader2, 
  CheckCircle2, 
  AlertCircle,
  Plus,
  Calendar,
  X,
  LogOut,
  Power,
  RefreshCw,
  UploadCloud,
  Settings,
  FilePlus,
  User as UserIcon,
  Lock,
  File as FileIcon,
  Database,
  ShieldCheck,
  ChevronRight
} from 'lucide-react';

const App: React.FC = () => {
  // Authentication & User State
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState<string | null>(null);
  
  // UI State
  const [showSettings, setShowSettings] = useState(false);
  const [showAccountModal, setShowAccountModal] = useState(false);
  const [exportDate, setExportDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [isDragging, setIsDragging] = useState(false);
  const [dbReady, setDbReady] = useState(false);
  
  // Data State
  const [documents, setDocuments] = useState<ExtractedDocument[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  
  // Registration State
  const [isFirstRun, setIsFirstRun] = useState(false);
  const [newUserName, setNewUserName] = useState('');
  const [newUserPassword, setNewUserPassword] = useState('');

  const fileInputRef = useRef<HTMLInputElement>(null);

  // INITIAL LOAD FROM DATABASE
  useEffect(() => {
    const initData = async () => {
      try {
        const allUsers = await db.users.toArray();
        setUsers(allUsers);
        setIsFirstRun(allUsers.length === 0);

        const auth = sessionStorage.getItem('cfm_converter_auth_user');
        if (auth) {
          setCurrentUser(JSON.parse(auth));
        }

        const allDocs = await db.documents.toArray();
        setDocuments(allDocs);
        setDbReady(true);
      } catch (err) {
        console.error("Database init error:", err);
      }
    };
    initData();
  }, []);

  // DERIVED DATA
  const userDocuments = useMemo(() => {
    if (!currentUser) return [];
    return documents.filter(d => d.userId === currentUser.id);
  }, [documents, currentUser]);

  const activeProcessingCount = useMemo(() => {
    return userDocuments.filter(d => d.status === 'processing' || d.status === 'pending').length;
  }, [userDocuments]);

  const isAdmin = currentUser?.role === 'admin';

  // AUTH ACTIONS
  const handleInitialSetup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !password) return;
    
    const adminUser: User = {
      id: uuidv4(),
      username: username,
      password: password,
      role: 'admin',
      isActive: true,
      createdAt: new Date().toISOString()
    };
    
    await db.users.add(adminUser);
    setUsers([adminUser]);
    setCurrentUser(adminUser);
    sessionStorage.setItem('cfm_converter_auth_user', JSON.stringify(adminUser));
    setIsFirstRun(false);
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const foundUser = users.find(u => u.username.toLowerCase() === username.toLowerCase() && u.password === password);
    if (foundUser) {
      if (!foundUser.isActive) {
        setLoginError('Account gedeactiveerd');
        return;
      }
      setCurrentUser(foundUser);
      sessionStorage.setItem('cfm_converter_auth_user', JSON.stringify(foundUser));
      setLoginError(null);
    } else {
      setLoginError('Gebruikersnaam of wachtwoord onjuist');
      setTimeout(() => setLoginError(null), 3000);
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    sessionStorage.removeItem('cfm_converter_auth_user');
    setUsername('');
    setPassword('');
  };

  const [ownNewPassword, setOwnNewPassword] = useState('');
  const [ownConfirmPassword, setOwnConfirmPassword] = useState('');

  const handleOwnPasswordChange = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    if (ownNewPassword !== ownConfirmPassword) {
      alert("Wachtwoorden komen niet overeen.");
      return;
    }

    await db.users.update(currentUser.id, { password: ownNewPassword });
    const updatedUsers = await db.users.toArray();
    setUsers(updatedUsers);
    
    const updatedCurrentUser = { ...currentUser, password: ownNewPassword };
    setCurrentUser(updatedCurrentUser);
    sessionStorage.setItem('cfm_converter_auth_user', JSON.stringify(updatedCurrentUser));

    alert("Uw wachtwoord is succesvol gewijzigd.");
    setOwnNewPassword('');
    setOwnConfirmPassword('');
    setShowAccountModal(false);
  };

  // FILE PROCESSING
  const processFiles = async (files: FileList | File[]) => {
    if (!files || !currentUser) return;

    const allowedTypes = ['application/pdf', 'image/jpeg', 'image/jpg', 'image/png'];
    const validFiles = Array.from(files).filter(file => allowedTypes.includes(file.type));
    
    if (validFiles.length === 0) return;

    const newDocs: ExtractedDocument[] = [];
    for (const file of validFiles) {
      const doc: ExtractedDocument = {
        id: uuidv4(),
        userId: currentUser.id,
        fileName: file.name,
        crv: '',
        alg: '',
        naam: '',
        adres: '',
        status: 'pending',
        createdAt: new Date().toISOString()
      };
      await db.documents.add(doc);
      newDocs.push(doc);
    }

    setDocuments(prev => [...prev, ...newDocs]);

    for (let i = 0; i < validFiles.length; i++) {
      const file = validFiles[i];
      const docId = newDocs[i].id;
      
      await db.documents.update(docId, { status: 'processing' });
      setDocuments(prev => prev.map(d => d.id === docId ? { ...d, status: 'processing' } : d));
      
      try {
        const reader = new FileReader();
        const base64 = await new Promise<string>((resolve, reject) => {
          reader.readAsDataURL(file);
          reader.onload = () => resolve(reader.result as string);
          reader.onerror = () => reject(new Error("Bestand kon niet worden gelezen."));
        });
        const result = await extractDocumentData(base64, file.type);
        
        await db.documents.update(docId, { ...result, status: 'completed' });
        setDocuments(prev => prev.map(d => d.id === docId ? { ...d, ...result, status: 'completed' } : d));
      } catch (error: any) {
        const errorMsg = error.message || 'Fout bij verwerken';
        await db.documents.update(docId, { status: 'error', error: errorMsg });
        setDocuments(prev => prev.map(d => d.id === docId ? { ...d, status: 'error', error: errorMsg } : d));
      }
    }
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files) processFiles(event.target.files);
    event.target.value = '';
  };

  const updateField = async (id: string, field: keyof ExtractedDocument, value: string) => {
    await db.documents.update(id, { [field]: value });
    setDocuments(prev => prev.map(d => d.id === id ? { ...d, [field]: value } : d));
  };

  const deleteDocument = async (id: string) => {
    await db.documents.delete(id);
    setDocuments(prev => prev.filter(d => d.id !== id));
  };

  const handleNewList = async () => {
    if (!currentUser) return;
    const count = userDocuments.length;
    if (count === 0) return;

    if (window.confirm(`Wilt u de lijst met ${count} items wissen?`)) {
      const idsToDelete = userDocuments.map(d => d.id);
      await db.documents.bulkDelete(idsToDelete);
      setDocuments(prev => prev.filter(doc => doc.userId !== currentUser.id));
    }
  };

  const generateCSV = () => {
    if (!currentUser) return;
    const d = new Date(exportDate);
    // DD-MM-YYYY
    const formattedDate = `${String(d.getDate()).padStart(2, '0')}-${String(d.getMonth() + 1).padStart(2, '0')}-${d.getFullYear()}`;
    
    /**
     * Header alignment for 6 columns (NO.; CRV; DIMAS/ALG; NAAM; ADRES; ALHIER)
     * Shifting the labels 1 column to the left by starting text after the first semicolon (Column 1).
     */
    const row1 = ";TER UITREIKING BESCHIKKINGEN DIMAS LANG VERBLIJF DOOR POSTKANTOOR;;;;";
    const row2 = ";KENNISGEVING V/H VOORNEMEN TOT:;;;" + formattedDate + ";";
    const row3 = ";;;;;"; // empty spacer
    const columns = "NO.;CRV;DIMAS/ALG;NAAM;ADRES;ALHIER";

    const rows = userDocuments
      .filter(doc => doc.status === 'completed')
      .map((doc, index) => `${index + 1};${doc.crv};${doc.alg};${doc.naam};${doc.adres};ALHIER`);
    
    const csvContent = "\uFEFF" + [row1, row2, row3, columns, ...rows].join('\n');
    
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `CFM_Export_${formattedDate}.csv`);
    link.click();
  };

  const addUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUserName || !newUserPassword) return;
    const newUser: User = {
      id: uuidv4(),
      username: newUserName,
      password: newUserPassword,
      role: 'user',
      isActive: true,
      createdAt: new Date().toISOString()
    };
    await db.users.add(newUser);
    setUsers(await db.users.toArray());
    setNewUserName(''); setNewUserPassword('');
  };

  const toggleUserStatus = async (id: string) => {
    const user = users.find(u => u.id === id);
    if (!user) return;
    await db.users.update(id, { isActive: !user.isActive });
    setUsers(await db.users.toArray());
  };

  const deleteUser = async (id: string) => {
    if (window.confirm('Gebruiker verwijderen?')) {
      await db.users.delete(id);
      await db.documents.where('userId').equals(id).delete();
      setUsers(await db.users.toArray());
      setDocuments(await db.documents.toArray());
    }
  };

  // LOGIN SCREEN RENDER LOGIC
  if (isFirstRun && !currentUser) {
    return (
      <div className="min-h-screen relative flex items-center justify-center bg-slate-950 overflow-hidden p-6 font-sans">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-emerald-500/10 blur-[120px] rounded-full animate-pulse"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-blue-500/10 blur-[120px] rounded-full animate-pulse"></div>
        <div className="w-full max-w-md relative z-10">
          <div className="bg-slate-900/40 backdrop-blur-2xl rounded-[2.5rem] p-10 border border-white/5 shadow-[0_32px_64px_-16px_rgba(0,0,0,0.5)]">
            <div className="flex flex-col items-center mb-8 text-center">
              <div className="p-4 bg-emerald-500/10 rounded-2xl mb-6 ring-1 ring-emerald-500/20">
                <ShieldCheck className="w-10 h-10 text-emerald-400" />
              </div>
              <h1 className="text-xl font-black text-white uppercase tracking-tight mb-2">Systeem Initialisatie</h1>
              <p className="text-slate-400 text-xs font-medium">Admin-account configuratie.</p>
            </div>
            <form onSubmit={handleInitialSetup} className="space-y-5">
              <div className="relative group">
                <UserIcon className="absolute left-5 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-slate-500 group-focus-within:text-emerald-400 transition-colors" />
                <input type="text" value={username} onChange={(e) => setUsername(e.target.value)} className="w-full bg-slate-800/50 border border-white/5 px-14 py-4 rounded-xl font-bold outline-none text-sm text-white placeholder:text-slate-600 focus:ring-2 ring-emerald-500/40 transition-all" placeholder="Admin naam..." required />
              </div>
              <div className="relative group">
                <Lock className="absolute left-5 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-slate-500 group-focus-within:text-emerald-400 transition-colors" />
                <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} className="w-full bg-slate-800/50 border border-white/5 px-14 py-4 rounded-xl font-bold outline-none text-sm text-white placeholder:text-slate-600 focus:ring-2 ring-emerald-500/40 transition-all" placeholder="Wachtwoord..." required />
              </div>
              <button type="submit" className="w-full bg-emerald-600 hover:bg-emerald-500 text-white py-4 rounded-xl font-black text-[10px] uppercase tracking-widest transition-all shadow-lg shadow-emerald-900/20 flex items-center justify-center gap-2 group active:scale-[0.98]">
                Start Database <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>
            </form>
          </div>
        </div>
      </div>
    );
  }

  if (!currentUser) {
    return (
      <div className="min-h-screen relative flex items-center justify-center bg-slate-950 overflow-hidden p-6 font-sans">
        <div className="absolute top-[-20%] right-[-10%] w-[60%] h-[60%] bg-blue-600/10 blur-[150px] rounded-full animate-pulse pointer-events-none"></div>
        <div className="absolute bottom-[-10%] left-[-20%] w-[50%] h-[50%] bg-slate-800/20 blur-[120px] rounded-full pointer-events-none"></div>
        <div className="w-full max-w-md relative z-10 animate-in fade-in zoom-in duration-700">
          <div className="bg-slate-900/40 backdrop-blur-3xl rounded-[2.5rem] p-10 md:p-12 border border-white/5 shadow-[0_40px_80px_-20px_rgba(0,0,0,0.6)]">
            <div className="flex flex-col items-center mb-10 text-center">
              <div className="floating-logo mb-8 drop-shadow-[0_0_30px_rgba(59,130,246,0.3)]">
                <Logo className="h-20 w-auto" />
              </div>
              <h1 className="text-2xl font-black text-white uppercase tracking-tighter mb-1">CFM Converter</h1>
              <p className="text-slate-500 text-[10px] font-bold uppercase tracking-[0.25em]">Digital Hub Access</p>
            </div>
            <form onSubmit={handleLogin} className="space-y-5">
              <div className="relative group">
                <UserIcon className="absolute left-5 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-slate-600 group-focus-within:text-blue-400 transition-colors" />
                <input type="text" value={username} onChange={(e) => setUsername(e.target.value)} className="w-full bg-slate-800/40 border border-white/5 px-14 py-4.5 rounded-xl font-bold outline-none text-sm text-white placeholder:text-slate-600 focus:ring-2 ring-blue-500/40 transition-all" placeholder="Gebruikersnaam" required />
              </div>
              <div className="relative group">
                <Lock className="absolute left-5 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-slate-600 group-focus-within:text-blue-400 transition-colors" />
                <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} className="w-full bg-slate-800/40 border border-white/5 px-14 py-4.5 rounded-xl font-bold outline-none text-sm text-white placeholder:text-slate-600 focus:ring-2 ring-blue-500/40 transition-all" placeholder="Wachtwoord" required />
              </div>
              {loginError && (
                <div className="bg-rose-500/10 border border-rose-500/20 py-3.5 px-4 rounded-xl flex items-center gap-3 animate-in shake duration-300">
                  <AlertCircle className="w-4.5 h-4.5 text-rose-500 flex-shrink-0" />
                  <p className="text-rose-500 text-[9px] font-black uppercase leading-tight">{loginError}</p>
                </div>
              )}
              <button type="submit" className="w-full bg-white text-slate-950 py-4.5 rounded-xl font-black text-[10px] uppercase tracking-widest transition-all shadow-xl hover:bg-slate-200 active:scale-[0.98] flex items-center justify-center gap-3">
                Inloggen <ChevronRight className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-slate-950 text-slate-200 font-sans" onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }} onDragLeave={() => setIsDragging(false)} onDrop={(e) => { e.preventDefault(); setIsDragging(false); if (e.dataTransfer.files) processFiles(e.dataTransfer.files); }}>
      <header className="bg-slate-900/80 backdrop-blur-md border-b border-white/5 px-6 py-4 flex items-center justify-between sticky top-0 z-20 shadow-xl">
        <div className="flex items-center gap-5">
          <Logo className="h-10 w-auto" />
          <div className="hidden sm:block">
            <h1 className="text-xs font-black text-white tracking-tight uppercase">CFM CONVERTER</h1>
            <p className="text-[7px] text-slate-500 font-bold uppercase">{currentUser.username} • {isAdmin ? 'ADMIN' : 'USER'}</p>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <div className="hidden lg:flex items-center gap-2 bg-slate-800/50 px-3 py-2 rounded-xl border border-white/5">
            <Calendar className="w-3.5 h-3.5 text-slate-400" />
            <input type="date" value={exportDate} onChange={(e) => setExportDate(e.target.value)} className="bg-transparent text-[9px] font-black outline-none [color-scheme:dark] text-white" />
          </div>
          <button onClick={() => setShowAccountModal(true)} className="p-2.5 text-slate-400 hover:text-white hover:bg-white/5 rounded-xl transition-all"><UserIcon className="w-4.5 h-4.5" /></button>
          {isAdmin && <button onClick={() => setShowSettings(true)} className="p-2.5 text-slate-400 hover:text-blue-400 hover:bg-white/5 rounded-xl transition-all"><Settings className="w-4.5 h-4.5" /></button>}
          <label className="cursor-pointer bg-blue-600 hover:bg-blue-500 text-white px-5 py-2.5 rounded-xl font-black transition-all flex items-center gap-2 text-[10px] shadow-lg shadow-blue-900/20 active:scale-95">
            <UploadCloud className="w-4.5 h-4.5" /> <span className="hidden sm:inline">IMPORT</span>
            <input type="file" ref={fileInputRef} className="hidden" multiple accept=".pdf,.jpg,.jpeg,.png" onChange={handleFileUpload} />
          </label>
          <button onClick={handleLogout} className="p-2.5 text-slate-500 hover:text-rose-500 transition-all"><LogOut className="w-4.5 h-4.5" /></button>
        </div>
      </header>

      <main className="flex-1 p-6 md:p-10 max-w-[1400px] mx-auto w-full flex flex-col gap-8 animate-in slide-in-from-bottom-4 duration-500">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            { label: 'Database Items', value: userDocuments.length, icon: Database, color: 'text-blue-500' },
            { label: 'Gereed voor Export', value: userDocuments.filter(d => d.status === 'completed').length, icon: CheckCircle2, color: 'text-emerald-400' },
            { label: 'Scanner Status', value: activeProcessingCount > 0 ? 'Verwerken...' : 'Gescanned', icon: RefreshCw, color: 'text-slate-500', spin: activeProcessingCount > 0 }
          ].map((stat, i) => (
            <div key={i} className="bg-slate-900/50 p-6 rounded-2xl border border-white/5 flex items-center justify-between shadow-sm group">
              <div>
                <p className="text-[9px] text-slate-500 font-black uppercase mb-1 tracking-wider">{stat.label}</p>
                <p className={`text-2xl font-black ${stat.color}`}>{stat.value}</p>
              </div>
              <stat.icon className={`w-10 h-10 ${stat.color} opacity-10 group-hover:opacity-25 transition-opacity ${stat.spin ? 'animate-spin' : ''}`} />
            </div>
          ))}
        </div>

        {userDocuments.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center py-24 bg-slate-900/40 rounded-[3rem] border-2 border-dashed border-white/5 shadow-inner">
             <div onClick={() => fileInputRef.current?.click()} className="cursor-pointer group flex flex-col items-center text-center px-8">
                <div className="w-24 h-24 bg-slate-800/50 border border-white/5 rounded-full flex items-center justify-center mb-8 group-hover:bg-blue-600 group-hover:scale-105 transition-all shadow-xl">
                  <FileIcon className="w-10 h-10 text-slate-400 group-hover:text-white" />
                </div>
                <h2 className="text-2xl font-black text-white uppercase mb-3 tracking-tight">Importeer Documenten</h2>
                <p className="text-slate-500 text-[10px] font-black uppercase tracking-[0.15em] max-w-sm leading-relaxed">Sleep bestanden hierheen om te starten</p>
             </div>
          </div>
        ) : (
          <div className="flex flex-col gap-6">
            <div className="flex justify-between items-center px-2">
               <h3 className="text-[10px] font-black uppercase text-slate-500 tracking-[0.2em]">Verwerkingslijst</h3>
               <div className="flex gap-3">
                 <button onClick={handleNewList} className="flex items-center gap-2 bg-slate-800/50 hover:bg-rose-900/20 hover:text-rose-500 text-slate-400 px-4 py-2 rounded-xl text-[9px] font-black uppercase transition-all border border-white/5"><FilePlus className="w-3.5 h-3.5" /> Leegmaken</button>
                 <button onClick={generateCSV} disabled={userDocuments.filter(d => d.status === 'completed').length === 0} className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-800 disabled:text-slate-600 text-white px-6 py-2 rounded-xl text-[9px] font-black uppercase transition-all shadow-lg active:scale-95"><Download className="w-3.5 h-3.5" /> Export Excel</button>
               </div>
            </div>

            <div className="bg-slate-900/50 rounded-3xl border border-white/5 overflow-hidden shadow-xl backdrop-blur-sm">
              <div className="overflow-x-auto">
                <table className="w-full text-left table-fixed">
                  <thead className="bg-slate-800/30 border-b border-white/5">
                    <tr>
                      <th className="px-6 py-5 text-[9px] font-black text-slate-500 uppercase tracking-widest w-16 text-center">NO.</th>
                      <th className="px-8 py-5 text-[9px] font-black text-slate-500 uppercase tracking-widest w-[160px]">CRV</th>
                      <th className="px-8 py-5 text-[9px] font-black text-slate-500 uppercase tracking-widest w-[140px]">DIMAS/ALG</th>
                      <th className="px-8 py-5 text-[9px] font-black text-slate-500 uppercase tracking-widest min-w-[320px]">NAAM</th>
                      <th className="px-8 py-5 text-[9px] font-black text-slate-500 uppercase tracking-widest min-w-[280px]">ADRES</th>
                      <th className="px-8 py-5 text-[9px] font-black text-slate-500 uppercase tracking-widest w-24 text-center">STATUS</th>
                      <th className="px-8 py-5 w-16"></th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {userDocuments.map((doc, index) => (
                      <tr key={doc.id} className="hover:bg-white/[0.01] transition-all group">
                        <td className="px-6 py-4">
                           <div className="bg-slate-800/30 border border-white/5 px-2 py-3 rounded-lg text-xs font-black text-slate-500 text-center select-none">
                              {index + 1}
                           </div>
                        </td>
                        <td className="px-8 py-4">
                          <input type="text" value={doc.crv} onChange={(e) => updateField(doc.id, 'crv', e.target.value)} className="bg-slate-800/30 border border-white/5 px-4 py-3 rounded-lg text-xs font-black text-white w-full outline-none focus:bg-slate-800/60 focus:ring-1 ring-blue-500/30 transition-all" />
                        </td>
                        <td className="px-8 py-4">
                          <input type="text" value={doc.alg} onChange={(e) => updateField(doc.id, 'alg', e.target.value)} className="bg-transparent px-1 py-3 text-xs font-bold text-slate-400 w-full outline-none focus:text-white transition-colors" />
                        </td>
                        <td className="px-8 py-4">
                          <input type="text" value={doc.naam} onChange={(e) => updateField(doc.id, 'naam', e.target.value)} className="bg-transparent px-1 py-3 text-sm font-black text-white uppercase w-full outline-none focus:text-blue-400 transition-colors whitespace-nowrap overflow-hidden text-ellipsis" />
                        </td>
                        <td className="px-8 py-4">
                          <input type="text" value={doc.adres} onChange={(e) => updateField(doc.id, 'adres', e.target.value)} className="bg-transparent px-1 py-3 text-[11px] font-medium text-slate-500 w-full outline-none focus:text-slate-300 transition-colors" />
                        </td>
                        <td className="px-8 py-4">
                          <div className="flex flex-col items-center gap-1.5">
                            {doc.status === 'processing' ? <Loader2 className="w-5 h-5 animate-spin text-blue-500" /> : 
                             doc.status === 'completed' ? <CheckCircle2 className="w-5 h-5 text-emerald-500" /> : 
                             <AlertCircle className="w-5 h-5 text-rose-500" />}
                            <span className="text-[8px] font-black uppercase text-slate-600 tracking-tighter">{doc.status}</span>
                          </div>
                        </td>
                        <td className="px-8 py-4">
                          <button onClick={() => deleteDocument(doc.id)} className="p-2 text-slate-700 hover:text-rose-500 transition-colors"><Trash2 className="w-4 h-4" /></button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Database/Settings Modal */}
      {showSettings && isAdmin && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-md p-4 animate-in fade-in duration-300">
          <div className="bg-slate-900 w-full max-w-3xl h-[80vh] rounded-[2.5rem] border border-white/5 flex flex-col overflow-hidden shadow-2xl">
            <div className="p-8 border-b border-white/5 flex justify-between items-center">
              <div>
                <h2 className="text-xl font-black uppercase tracking-tight">Database Beheer</h2>
                <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mt-1">Systeem Administratie</p>
              </div>
              <button onClick={() => setShowSettings(false)} className="p-3 hover:bg-white/5 rounded-full transition-all text-slate-400 hover:text-white"><X className="w-6 h-6" /></button>
            </div>
            <div className="flex-1 overflow-y-auto p-8 grid grid-cols-1 md:grid-cols-2 gap-10">
               <div>
                  <h3 className="text-[9px] font-black uppercase text-slate-500 mb-6 tracking-widest flex items-center gap-2">
                    <Plus className="w-4 h-4" /> Account Toevoegen
                  </h3>
                  <form onSubmit={addUser} className="space-y-4">
                     <input type="text" value={newUserName} onChange={(e) => setNewUserName(e.target.value)} placeholder="Gebruikersnaam" className="w-full bg-slate-800/50 border border-white/5 px-6 py-4 rounded-xl text-sm font-bold text-white outline-none focus:ring-2 ring-blue-500/20" required />
                     <input type="password" value={newUserPassword} onChange={(e) => setNewUserPassword(e.target.value)} placeholder="Wachtwoord" className="w-full bg-slate-800/50 border border-white/5 px-6 py-4 rounded-xl text-sm font-bold text-white outline-none focus:ring-2 ring-blue-500/20" required />
                     <button type="submit" className="w-full bg-blue-600 hover:bg-blue-500 py-4 rounded-xl text-[9px] font-black uppercase tracking-widest shadow-lg transition-all active:scale-95">Toevoegen</button>
                  </form>
               </div>
               <div>
                  <h3 className="text-[9px] font-black uppercase text-slate-500 mb-6 tracking-widest flex items-center gap-2">
                    <UserIcon className="w-4 h-4" /> Gebruikers
                  </h3>
                  <div className="space-y-3">
                    {users.map(u => (
                      <div key={u.id} className="p-4 bg-slate-950/50 rounded-2xl border border-white/5 flex items-center justify-between group">
                         <div className="flex items-center gap-4">
                            <div className="w-10 h-10 rounded-xl bg-slate-800 border border-white/5 flex items-center justify-center text-sm font-black text-blue-400">{u.username[0].toUpperCase()}</div>
                            <div>
                               <p className="text-sm font-black text-white">{u.username}</p>
                               <p className="text-[8px] font-black text-slate-600 uppercase tracking-widest">{u.role}</p>
                            </div>
                         </div>
                         <div className="flex gap-2">
                            <button onClick={() => toggleUserStatus(u.id)} className={`p-2 rounded-xl transition-all ${u.isActive ? 'text-emerald-500 hover:bg-emerald-500/10' : 'text-slate-700 hover:bg-slate-800'}`}><Power className="w-5 h-5" /></button>
                            <button onClick={() => deleteUser(u.id)} disabled={u.id === currentUser.id} className="p-2 text-slate-700 hover:text-rose-500 disabled:opacity-20 hover:bg-rose-500/10 rounded-xl transition-all"><Trash2 className="w-5 h-5" /></button>
                         </div>
                      </div>
                    ))}
                  </div>
               </div>
            </div>
          </div>
        </div>
      )}

      {/* Account Info Modal */}
      {showAccountModal && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/90 backdrop-blur-md p-4 animate-in fade-in duration-300">
          <div className="bg-slate-900 w-full max-sm rounded-[2.5rem] p-10 border border-white/5 shadow-2xl">
             <div className="flex justify-between items-center mb-10">
                <h3 className="text-lg font-black uppercase tracking-tight">Profiel</h3>
                <button onClick={() => setShowAccountModal(false)} className="p-2.5 hover:bg-white/5 rounded-full transition-all text-slate-400"><X className="w-6 h-6" /></button>
             </div>
             <form onSubmit={handleOwnPasswordChange} className="space-y-5">
                <div className="p-6 bg-slate-800/40 rounded-2xl border border-white/5 mb-2">
                   <p className="text-[8px] font-black text-slate-500 uppercase tracking-widest mb-1.5">Ingelogd als</p>
                   <p className="text-xl font-black text-white">{currentUser.username}</p>
                </div>
                <div className="space-y-3">
                  <input type="password" value={ownNewPassword} onChange={(e) => setOwnNewPassword(e.target.value)} className="w-full bg-slate-800/50 border border-white/5 px-6 py-4 rounded-xl text-sm font-bold text-white outline-none focus:ring-2 ring-emerald-500/20" placeholder="Nieuw wachtwoord" required />
                  <input type="password" value={ownConfirmPassword} onChange={(e) => setOwnConfirmPassword(e.target.value)} className="w-full bg-slate-800/50 border border-white/5 px-6 py-4 rounded-xl text-sm font-bold text-white outline-none focus:ring-2 ring-emerald-500/20" placeholder="Bevestig wachtwoord" required />
                </div>
                <button type="submit" className="w-full py-4 text-[9px] font-black uppercase tracking-widest bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl transition-all shadow-lg active:scale-95">Wachtwoord Bijwerken</button>
             </form>
          </div>
        </div>
      )}

      <footer className="bg-slate-900/50 border-t border-white/5 px-8 py-5 flex flex-col md:flex-row items-center justify-between gap-6 mt-auto backdrop-blur-sm">
        <div className="flex items-center gap-8">
          <p className="text-[9px] text-slate-500 font-black uppercase tracking-[0.2em]">&copy; {new Date().getFullYear()} CFM Digital Hub</p>
          <div className="flex items-center gap-3 px-4 py-2 bg-slate-950/50 rounded-xl border border-white/5">
             <div className={`w-2 h-2 rounded-full ${dbReady ? 'bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.5)]' : 'bg-slate-700'}`}></div>
             <span className="text-[9px] font-black text-slate-600 uppercase tracking-widest">{dbReady ? 'ONLINE' : 'CONNECTING...'}</span>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <span className="text-[8px] text-slate-700 font-black uppercase tracking-widest">Version 1.2.0-PRO</span>
        </div>
      </footer>
    </div>
  );
};

export default App;
